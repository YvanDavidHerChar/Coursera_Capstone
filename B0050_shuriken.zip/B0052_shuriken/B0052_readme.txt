The GRIMA Database of X-ray images
Machine Intelligence Group (GRIMA)
Department of Computer Science
Pontificia Universidad Catolica de Chile

The X-ray images of our experiments were acquired using a digital X-ray detector (Canon, model CXDI-50G), an X-ray emitter tube (Poskom, model PXM-20BT) and a lead security cabinet to isolate the inspection environment.


X-ray tube voltage = 55 kV
X-ray tube current = 5 mA

Images captured by Vladimir Riffo, Irene Zuccar and German Mondragon
2010-2014, Santiago de Chile

Contact: 
Domingo Mery
dmery@ing.puc.cl
http://dmery.ing.puc.cl

(c) All rights reserved. These images can be used for educational and research purposes only.
